import cv2
import dlib
from scipy.spatial import distance
from playsound import playsound

# Function to calculate the eye aspect ratio (EAR)
def eye_aspect_ratio(eye):
    A = distance.euclidean(eye[1], eye[5])
    B = distance.euclidean(eye[2], eye[4])
    C = distance.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

# Load face detector and shape predictor from dlib
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")  # Download this file from http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2

# Constants for eye landmarks
left_eye_indices = [36, 37, 38, 39, 40, 41]
right_eye_indices = [42, 43, 44, 45, 46, 47]

# Threshold for drowsiness detection (adjust as needed)
threshold = 0.25

# Initialize video capture
cap = cv2.VideoCapture(0)

# Initialize alarm flag and frame counter
alarm_on = False
frame_counter = 0

# Function to play the alarm sound
def play_alarm():
    playsound("Alarm .mp3")  # Replace with the path to your alarm sound file

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)

    for face in faces:
        landmarks = predictor(gray, face)
        left_eye = [(landmarks.part(idx).x, landmarks.part(idx).y) for idx in left_eye_indices]
        right_eye = [(landmarks.part(idx).x, landmarks.part(idx).y) for idx in right_eye_indices]

        left_ear = eye_aspect_ratio(left_eye)
        right_ear = eye_aspect_ratio(right_eye)
        avg_ear = (left_ear + right_ear) / 2.0

        # If the average eye aspect ratio is below the threshold, increase the frame counter
        if avg_ear < threshold:
            frame_counter += 1

            # If the frame counter exceeds a certain threshold, set the alarm flag and play the alarm
            if frame_counter >= 20:
                if not alarm_on:
                    play_alarm()
                    alarm_on = True
        else:
            frame_counter = 0
            alarm_on = False

        # Draw facial landmarks on the frame
        for point in landmarks.parts():
            cv2.circle(frame, (point.x, point.y), 1, (0, 255, 0), 1)

    cv2.imshow("Driver Drowsiness Detection", frame)

    # Break the loop if 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object
cap.release()
cv2.destroyAllWindows()
