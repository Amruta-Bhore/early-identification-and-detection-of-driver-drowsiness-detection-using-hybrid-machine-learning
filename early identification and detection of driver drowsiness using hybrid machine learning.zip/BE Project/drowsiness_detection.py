import cv2
import dlib
import pygame
import numpy as np
from scipy.spatial import distance

# Initialize pygame
pygame.init()

# Function to calculate the eye aspect ratio (EAR)
def eye_aspect_ratio(eye):
    A = distance.euclidean(eye[1], eye[5])
    B = distance.euclidean(eye[2], eye[4])
    C = distance.euclidean(eye[0], eye[3])

    ear = (A + B) / (2.0 * C)
    return ear

# Function to calculate the mouth aspect ratio (MAR)
def mouth_aspect_ratio(mouth):
    A = distance.euclidean(mouth[14], mouth[18])
    B = distance.euclidean(mouth[12], mouth[16])
    mar = A / B
    return mar

# Function to calculate the face aspect ratio (FAR)
def face_aspect_ratio(face):
    x, y, w, h = face
    far = w / h
    return far

# Function to draw eyes, mouth, and face on the frame
def draw_features(frame, left_eye, right_eye, mouth, face):
    left_eye_hull = cv2.convexHull(left_eye)
    right_eye_hull = cv2.convexHull(right_eye)
    mouth_hull = cv2.convexHull(mouth)

    cv2.drawContours(frame, [left_eye_hull], -1, (0, 255, 0), 1)
    cv2.drawContours(frame, [right_eye_hull], -1, (0, 255, 0), 1)
    cv2.drawContours(frame, [mouth_hull], -1, (0, 255, 0), 1)
    cv2.rectangle(frame, (face[0], face[1]), (face[0] + face[2], face[1] + face[3]), (255, 0, 0), 2)

# Function to convert dlib shape to numpy array
def shape_to_np(shape, dtype="int"):
    coords = np.zeros((68, 2), dtype=dtype)
    for i in range(0, 68):
        coords[i] = (shape.part(i).x, shape.part(i).y)
    return coords

# Constants
EAR_THRESHOLD = 0.3  # Adjust this threshold based on your observations
MAR_THRESHOLD = 0.7  # Adjust this threshold based on your observations
FAR_THRESHOLD = 1.8  # Adjust this threshold based on your observations
CONSEC_FRAMES = 48  # Number of consecutive frames for drowsiness detection

# Load the face detector and facial landmark predictor from dlib
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")  # Path to the shape predictor file

# Initialize variables
frame_counter = 0
drowsy = False

# Open the video stream using a different backend
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the grayscale frame
    faces = detector(gray)

    for face in faces:
        shape = predictor(gray, face)
        shape = shape_to_np(shape)

        # Extract the left and right eye coordinates, mouth coordinates, and face rectangle
        left_eye = shape[42:48]
        right_eye = shape[36:42]
        mouth = shape[48:68]
        face_rect = (face.left(), face.top(), face.width(), face.height())

        # Calculate the eye aspect ratio for both eyes
        ear_left = eye_aspect_ratio(left_eye)
        ear_right = eye_aspect_ratio(right_eye)

        # Calculate the mouth aspect ratio
        mar = mouth_aspect_ratio(mouth)

        # Calculate the face aspect ratio
        far = face_aspect_ratio(face_rect)

        # Average the EAR for both eyes
        ear_avg = (ear_left + ear_right) / 2.0

        # Draw the eyes, mouth, and face on the frame
        draw_features(frame, left_eye, right_eye, mouth, face_rect)

        # Check if the EAR, MAR, or FAR is below the respective threshold
        if ear_avg < EAR_THRESHOLD or mar > MAR_THRESHOLD or far < FAR_THRESHOLD:
            frame_counter += 1
            if frame_counter >= CONSEC_FRAMES:
                cv2.putText(frame, "Drowsiness Detected", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                drowsy = True
                # Play alarm sound using pygame
                pygame.mixer.Sound("alarm.mpeg").play()
            else:
                frame_counter = 0
                drowsy = False

    # Display the frame
    cv2.imshow("Drowsiness and Yawning Detection", frame)

    # Break the loop if 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close the window
cap.release()
cv2.destroyAllWindows()
